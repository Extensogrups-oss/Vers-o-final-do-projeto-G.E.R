# G.E.R. — Sistema de Gestão de Estoque e Retaguarda

Projeto acadêmico de extensão para o estudo de previsão de demanda, ficha técnica, CMV e controle de estoque do restaurante Sabor de Minas.

## Arquitetura

Navegador (HTML/CSS/JS) → API Node.js + Express → PostgreSQL. O navegador não acessa o banco diretamente. A autenticação e as permissões são verificadas no servidor. A sessão é **por aba**: o login devolve um token aleatório que o navegador guarda no `sessionStorage` da aba e envia em `Authorization: Bearer`; o servidor guarda só o hash (SHA-256) do token na tabela `session` do PostgreSQL, com expiração de 15 minutos de ociosidade. Assim, duas abas do mesmo navegador podem estar logadas com usuários diferentes sem interferir uma na outra.

## Requisitos

- PostgreSQL 14 ou superior e pgAdmin (ou `psql`).
- Node.js 20 ou superior e npm.
- Git (opcional para execução local; necessário para publicar no GitHub).

## Instalação do banco

1. Crie um banco vazio chamado `ger` no PostgreSQL.
2. Abra o Query Tool do banco `ger` no pgAdmin.
3. Execute todo o conteúdo de `banco/schema.sql`.
4. Execute todo o conteúdo de `banco/seed.sql`.
5. Confira em `Schemas > public > Tables` se as tabelas foram criadas e consulte `vw_saldo_critico` e `vw_cmv_prato`.

O `seed.sql` insere somente dados demonstrativos de cardápio, insumos, fichas técnicas e datas de demanda. Não cria usuários nem senhas. O primeiro usuário Dono é criado pelo próprio sistema na primeira abertura.

## Instalação da aplicação

No terminal, dentro da pasta `GER`:

```bash
npm install
```

Copie `.env.example` para `.env` e edite `DATABASE_URL` com usuário, senha, host e banco PostgreSQL locais. Gere um segredo forte para `SESSION_SECRET` (por exemplo, com `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`). Nunca envie `.env` ao GitHub.

Inicie o servidor:

```bash
npm start
```

Acesse `http://localhost:3000`. No primeiro acesso, informe nome, e-mail e senha para criar o Dono. Depois, o Dono cadastra os demais usuários. Use senha forte e não compartilhe credenciais reais em demonstrações.

## Regras transacionais importantes

- Venda lançada diretamente no G.E.R. (`origem='GER'`): se qualquer ingrediente estiver insuficiente, a trigger levanta erro e a transação inteira sofre rollback. A API devolve HTTP 409 com explicação do ingrediente, saldo, quantidade necessária e confirmação de que nada foi gravado.
- Venda importada do Mestre (`origem='MESTRE'`): a venda consolidada é preservada; o que houver de estoque é baixado até zero e o faltante é gravado em `divergencia_estoque`. O saldo nunca fica negativo. `codigo_externo` único evita importar a mesma venda duas vezes.
- A trigger de baixa é uma constraint trigger diferida até o commit, assim ela enxerga todos os itens da venda. Não faça outra baixa de estoque no JavaScript/Node, para não duplicar consumo.
- Fator de demanda influencia previsão e estoque mínimo dinâmico. Não multiplica a quantidade física consumida por uma venda já realizada.
- Entradas chamam `fn_registrar_entrada`, que atualiza o custo médio ponderado. Perdas chamam `fn_registrar_perda`, com justificativa, movimentação e auditoria na mesma transação.

## Endpoints implementados

| Método | Endpoint | Uso / perfil |
|---|---|---|
| GET | `/api/status` | Verifica se o primeiro Dono já foi criado |
| POST | `/api/primeiro-dono` | Criação inicial, somente enquanto não existir usuário |
| POST | `/api/login` | Autenticação |
| POST | `/api/logout` | Encerrar sessão |
| GET | `/api/me` | Usuário autenticado |
| POST | `/api/senha` | Alterar senha |
| GET/POST | `/api/usuarios` | Listar/criar usuários (Dono) |
| GET/POST | `/api/insumos` | Consultar/cadastrar insumos |
| POST | `/api/insumos/:id/entrada` | Entrada e custo médio ponderado |
| POST | `/api/insumos/:id/perdas` | Perda com auditoria |
| GET/POST | `/api/pratos` | Consultar/cadastrar pratos |
| GET/PUT | `/api/pratos/:id/ficha` | Consultar/editar ficha técnica |
| GET/POST | `/api/calendario` | Consultar/atualizar fatores de demanda |
| GET | `/api/estoque/critico` | View de estoque crítico |
| GET/POST | `/api/vendas` | Consultar/criar venda direta |
| POST | `/api/vendas/importar` | Importar venda consolidada do PDV com código externo e itens já vinculados aos pratos |
| GET | `/api/auditoria` | Consultar movimentações |
| GET | `/api/resultado-dia` | Faturamento, CMV, lucro bruto e margem do dia (Dono/Gerente) |
| GET/POST | `/api/relatos` | Relatos de auditoria |
| GET | `/api/health` | Verificar conexão com o banco |

O endpoint de importação recebe dados já interpretados e mapeados para `id_prato`. O leitor de XML/CSV do protótipo original ainda precisa ser ligado a esse endpoint e validado com arquivos reais de exportação do Mestre Sistemas. Não envie XML fiscal real ao GitHub.

## Testes manuais recomendados

1. Crie o Dono e entre no sistema.
2. Cadastre um usuário de cada perfil e confirme que o backend retorna 403 em operações não permitidas.
3. Registre uma entrada de insumo com custo diferente e confira o novo custo médio.
4. Lance uma perda e confira `movimentacao_estoque` e `auditoria`.
5. Monte uma venda direta com estoque suficiente e confira a baixa pela ficha técnica.
6. Tente uma venda direta com estoque insuficiente: deve retornar 409 e manter saldo e venda inalterados.
7. Importe uma venda com `codigo_externo` inédito e estoque insuficiente: deve registrar venda, saldo zero e divergência.
8. Repita o mesmo `codigo_externo`: deve retornar 409 e não duplicar a venda.
9. Consulte `vw_saldo_critico`, `vw_cmv_prato`, `log_acesso` e `divergencia_estoque`.

## GitHub

Crie um repositório vazio no GitHub e, dentro da pasta do projeto:

```bash
git init
git add .
git commit -m "Estrutura inicial do G.E.R."
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/ger.git
git push -u origin main
```

Nunca faça commit de `.env`, senhas, dados pessoais reais, XML fiscal ou cópias de banco de produção. Use `.env.example` como modelo sem credenciais.

## Limitações conhecidas desta entrega

- A interface integrada é uma primeira versão funcional para autenticação, visão geral, consulta/cadastro simples de insumos, entrada, perda, cardápio/CMV, venda direta, calendário e movimentações. O protótipo anterior foi preservado em `docs/originais/` para não perder seu layout e funções demonstrativas.
- A importação do Mestre está disponível na API, mas a tela de leitura de XML/CSV do protótipo ainda precisa ser conectada e testada com o formato efetivamente exportado pelo estabelecimento.
- O painel de usuários já tem rotas de backend, mas o formulário administrativo ainda precisa ser acrescentado à interface integrada.
- O relatório acadêmico e os diagramas BrModelo originais foram preservados. Leia `docs/modelagem/LEIA-ME-modelagem.md` para complementar MER/MLD no BrModelo.
- Não foi possível afirmar teste de integração com PostgreSQL real neste ambiente. O script e a aplicação precisam ser executados na máquina do grupo conforme os passos acima.

As rotas administrativas adicionais são `PUT /api/usuarios/:id/status` (ativar/desativar) e `POST /api/usuarios/:id/redefinir-senha` (gera senha provisória que deve ser entregue por canal seguro). O sistema força a troca da senha provisória no primeiro acesso.
