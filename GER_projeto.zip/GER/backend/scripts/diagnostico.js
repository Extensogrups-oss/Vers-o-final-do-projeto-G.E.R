// Verifica ambiente, banco e estado do acesso. Uso: npm run diagnostico
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });
const db = require('../db');

const ok = m => console.log('  [OK]   ' + m);
const aviso = m => console.log('  [ATENÇÃO] ' + m);
const erro = m => { console.log('  [ERRO] ' + m); problemas++; };
let problemas = 0;

(async () => {
  console.log('\n== Arquivo .env ==');
  if (process.env.DATABASE_URL) ok('DATABASE_URL definido'); else erro('DATABASE_URL ausente no .env');
  if (!process.env.SESSION_SECRET) erro('SESSION_SECRET ausente no .env (o servidor não sobe sem ele)');
  else if (/SUBSTITUA/i.test(process.env.SESSION_SECRET)) aviso('SESSION_SECRET ainda é o texto de exemplo; troque por um segredo longo.');
  else ok('SESSION_SECRET definido');
  if (process.env.NODE_ENV === 'production') aviso('NODE_ENV=production exige HTTPS para o cookie de sessão. Em http://localhost use NODE_ENV=development, senão o login "não segura".');
  else ok(`NODE_ENV=${process.env.NODE_ENV || '(vazio)'}`);

  console.log('\n== Banco de dados ==');
  try { await db.query('SELECT 1'); ok('Conexão com o PostgreSQL funcionando'); }
  catch (e) { erro('Não conectou ao banco: ' + e.message); return; }

  const tabelas = ['cargo','usuario','insumo','prato','calendario_demanda','ficha_tecnica_compoe','venda','item_venda','movimentacao_estoque','auditoria','tentativas_login','log_acesso','importacao_pdv','divergencia_estoque','relato_auditoria'];
  const existentes = (await db.query("SELECT table_name FROM information_schema.tables WHERE table_schema='public'")).rows.map(r => r.table_name);
  const faltando = tabelas.filter(t => !existentes.includes(t));
  if (faltando.length) erro('Tabelas ausentes: ' + faltando.join(', ') + '. Execute banco/schema.sql em um banco vazio.'); else ok('Todas as tabelas do modelo existem');

  if (existentes.includes('usuario')) {
    const cols = (await db.query("SELECT column_name FROM information_schema.columns WHERE table_name='usuario'")).rows.map(r => r.column_name);
    const falt = ['senha_hash','trocar_senha','ativo','tentativas_falhas','bloqueado_ate','fk_cargo_id_cargo'].filter(c => !cols.includes(c));
    if (falt.length) erro('Tabela usuario desatualizada; faltam colunas: ' + falt.join(', ')); else ok('Estrutura da tabela usuario correta');
  }
  if (existentes.includes('session')) {
    const cols = (await db.query("SELECT column_name FROM information_schema.columns WHERE table_name='session'")).rows.map(r => r.column_name);
    if (!['sid','sess','expire'].every(c => cols.includes(c))) erro('Tabela session com estrutura inesperada (pode quebrar o login). Apague-a: DROP TABLE session; o sistema recria sozinho.'); else ok('Tabela de sessões correta');
  } else ok('Tabela de sessões será criada automaticamente na primeira execução');

  if (existentes.includes('cargo')) {
    const c = (await db.query('SELECT nome FROM cargo')).rows.map(r => r.nome);
    if (!c.includes('Dono')) erro("Cargo 'Dono' inexistente. Execute banco/seed.sql (ou 'npm run dono', que cria o cargo).");
    else ok('Cargos cadastrados: ' + c.join(', '));
  }

  if (existentes.includes('usuario') && existentes.includes('cargo')) {
    console.log('\n== Usuários ==');
    const us = (await db.query('SELECT u.nome,u.email,u.ativo,u.bloqueado_ate,c.nome AS cargo FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo ORDER BY u.id_usuario')).rows;
    if (!us.length) console.log('  (nenhum usuário cadastrado)');
    us.forEach(u => console.log(`  - ${u.nome} <${u.email}> | ${u.cargo} | ${u.ativo ? 'ativo' : 'INATIVO'}${u.bloqueado_ate && new Date(u.bloqueado_ate) > new Date() ? ' | BLOQUEADO até ' + new Date(u.bloqueado_ate).toLocaleString('pt-BR') : ''}`));
    const donosAtivos = us.filter(u => u.cargo === 'Dono' && u.ativo);
    console.log('\n== Resultado ==');
    if (!donosAtivos.length) console.log('  Nenhum Dono ativo: a tela inicial vai pedir a criação do Dono (primeiro acesso).');
    else console.log(`  Já existe Dono ativo (${donosAtivos.map(d => d.email).join(', ')}): a tela mostrará o LOGIN, não o cadastro.\n  Se não lembra a senha, rode: npm run dono`);
  }
  console.log(problemas ? `\n${problemas} problema(s) encontrado(s) acima.\n` : '\nNenhum problema estrutural encontrado.\n');
})().catch(e => { console.error('Falha no diagnóstico:', e.message); process.exitCode = 1; }).finally(() => db.end());
