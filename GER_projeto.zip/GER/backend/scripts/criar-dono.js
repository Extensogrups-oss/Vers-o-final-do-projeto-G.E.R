// Cria ou recupera o usuário Dono direto no banco (acesso garantido pelo terminal).
// Uso:  npm run dono
//       npm run dono -- --nome "Fulano" --email fulano@x.com --senha "Senha1234" --sim
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });
const readline = require('readline');
const bcrypt = require('bcrypt');
const db = require('../db');

const args = {};
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (a === '--sim') args.sim = true;
  else if (a.startsWith('--')) args[a.slice(2)] = process.argv[++i];
}

function perguntar(texto, { oculto = false } = {}) {
  return new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: !!process.stdin.isTTY });
    process.stdout.write(texto);
    if (oculto && process.stdin.isTTY) rl._writeToOutput = () => {};
    rl.question('', resposta => { rl.close(); if (oculto) process.stdout.write('\n'); resolve(resposta.trim()); });
  });
}

const senhaValida = s => s.length >= 8 && /[A-Za-zÀ-ÿ]/.test(s) && /[0-9]/.test(s);

(async () => {
  try {
    await db.query('SELECT 1');
    const donos = await db.query("SELECT u.id_usuario,u.nome,u.email,u.ativo FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo WHERE c.nome='Dono' ORDER BY u.id_usuario");
    if (donos.rowCount) {
      console.log('\nDonos já cadastrados:');
      donos.rows.forEach(d => console.log(`  - ${d.nome} <${d.email}> ${d.ativo ? '(ativo)' : '(INATIVO)'}`));
      console.log('Informe o e-mail de um deles para redefinir a senha, ou um e-mail novo para criar outro Dono.\n');
    } else {
      console.log('\nNenhum Dono cadastrado. Vamos criar o primeiro.\n');
    }

    const email = String(args.email || await perguntar('E-mail (será o login): ')).trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error('E-mail inválido.');
    const existente = await db.query('SELECT id_usuario,nome FROM usuario WHERE lower(email)=$1', [email]);
    const nome = String(args.nome || (existente.rowCount ? existente.rows[0].nome : await perguntar('Nome completo: '))).trim();
    if (!nome) throw new Error('Informe o nome.');
    const senha = String(args.senha || await perguntar('Nova senha (mín. 8, com letras e números; não aparece enquanto digita): ', { oculto: true }));
    if (!senhaValida(senha)) throw new Error('A senha precisa ter ao menos 8 caracteres, com letras e números.');
    if (!args.sim && !args.senha) {
      const conf = await perguntar('Repita a senha: ', { oculto: true });
      if (conf !== senha) throw new Error('As senhas não coincidem.');
    }

    const hash = await bcrypt.hash(senha, 12);
    const client = await db.connect();
    try {
      await client.query('BEGIN');
      await client.query("INSERT INTO cargo(nome) VALUES('Dono') ON CONFLICT(nome) DO NOTHING");
      const cargo = (await client.query("SELECT id_cargo FROM cargo WHERE nome='Dono'")).rows[0].id_cargo;
      let id;
      if (existente.rowCount) {
        id = existente.rows[0].id_usuario;
        await client.query('UPDATE usuario SET nome=$1,senha_hash=$2,trocar_senha=false,ativo=true,tentativas_falhas=0,bloqueado_ate=NULL,fk_cargo_id_cargo=$3 WHERE id_usuario=$4', [nome, hash, cargo, id]);
      } else {
        id = (await client.query('INSERT INTO usuario(nome,email,senha_hash,trocar_senha,fk_cargo_id_cargo) VALUES($1,$2,$3,false,$4) RETURNING id_usuario', [nome, email, hash, cargo])).rows[0].id_usuario;
      }
      await client.query('DELETE FROM tentativas_login WHERE email=$1', [email]);
      await client.query("INSERT INTO log_acesso(email_tentado,fk_usuario_id_usuario,evento,detalhes) VALUES($1,$2,$3,'Dono criado/recuperado pelo terminal (npm run dono).')", [email, id, existente.rowCount ? 'TROCA_SENHA' : 'USUARIO_CRIADO']);
      await client.query('COMMIT');
    } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }

    console.log(`\nPronto! ${existente.rowCount ? 'Senha redefinida' : 'Dono criado'}: ${email}\nAbra http://localhost:${process.env.PORT || 3000} e entre com esse e-mail e a senha informada.`);
  } catch (e) {
    console.error('\nNão foi possível concluir:', e.message);
    if (/ECONNREFUSED|password|authentication|does not exist/i.test(e.message)) console.error('Confira o PostgreSQL ligado e o DATABASE_URL no arquivo .env. Rode: npm run diagnostico');
    process.exitCode = 1;
  } finally { await db.end(); }
})();
