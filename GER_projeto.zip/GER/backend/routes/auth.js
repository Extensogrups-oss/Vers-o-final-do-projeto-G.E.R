const router = require('express').Router();
const bcrypt = require('bcrypt');
const db = require('../db');
const { permitir } = require('../middleware/auth');
const { iniciarSessao, encerrarSessao, revogarSessoesUsuario } = require('../middleware/sessao');
const log = async (email, evento, id, ip, detalhes=null) => db.query('INSERT INTO log_acesso(email_tentado,fk_usuario_id_usuario,evento,ip_origem,detalhes) VALUES($1,$2,$3,$4,$5)',[email,id,evento,ip,detalhes]);
router.get('/status', async(req,res,next)=>{try{const r=await db.query("SELECT EXISTS(SELECT 1 FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo WHERE c.nome='Dono' AND u.ativo) AS inicializado");res.set('Cache-Control','no-store');res.json({inicializado:r.rows[0].inicializado});}catch(e){next(e)}});
router.post('/primeiro-dono', async (req,res,next)=>{try{
 const {nome,email,senha}=req.body||{}; if(!nome||!email||!senha||senha.length<8||!/[A-Za-zÀ-ÿ]/.test(senha)||!/[0-9]/.test(senha)) return res.status(400).json({erro:'Informe nome, e-mail e senha com ao menos 8 caracteres, incluindo letras e números.'});
 const n=await db.query("SELECT count(*)::int AS n FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo WHERE c.nome='Dono' AND u.ativo"); if(n.rows[0].n) return res.status(409).json({erro:'Já existe um administrador ativo. Entre com o e-mail e a senha cadastrados.'});
 const cargo=await db.query("SELECT id_cargo FROM cargo WHERE nome='Dono'");
 if(!cargo.rowCount) return res.status(500).json({erro:'Perfil de administrador não encontrado. Verifique se a carga inicial do banco foi executada.'}); const hash=await bcrypt.hash(senha,12);
 const r=await db.query('INSERT INTO usuario(nome,email,senha_hash,trocar_senha,fk_cargo_id_cargo) VALUES($1,lower($2),$3,false,$4) RETURNING id_usuario,nome,email',( [nome,email,hash,cargo.rows[0].id_cargo]));
 const usuario={id:r.rows[0].id_usuario,nome:r.rows[0].nome,email:r.rows[0].email,cargo:'Dono'}; const token=await iniciarSessao(usuario); await log(email,'USUARIO_CRIADO',r.rows[0].id_usuario,req.ip); res.status(201).json({...usuario,token});
 }catch(e){next(e)}});
router.post('/login', async(req,res,next)=>{try{
 const email=String(req.body?.email||'').trim().toLowerCase(), senha=String(req.body?.senha||''); if(!email||!senha) return res.status(400).json({erro:'Informe e-mail e senha.'});
 const q=await db.query('SELECT u.*,c.nome AS cargo FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo WHERE lower(u.email)=$1',[email]); const u=q.rows[0];
 // Diferencia uma conta desativada de uma combinação de credenciais incorreta.
 if(u && !u.ativo){await log(email,'LOGIN_FALHA',u.id_usuario,req.ip,'Tentativa de acesso com perfil desativado.');return res.status(403).json({erro:'Este perfil está desativado. Solicite ao responsável pelo sistema a reativação do seu acesso.'});}
 const rate=await db.query('SELECT * FROM tentativas_login WHERE email=$1',[email]);
 if(rate.rows[0]?.bloqueado_ate && new Date(rate.rows[0].bloqueado_ate)>new Date()) return res.status(429).json({erro:'E-mail temporariamente bloqueado por excesso de tentativas. Aguarde cinco minutos.'});
 if(!u){await log(email,'LOGIN_FALHA',null,req.ip,'E-mail não cadastrado.');return res.status(404).json({erro:'E-mail não encontrado. Confira o endereço informado ou solicite o cadastro ao responsável pelo sistema.'});}
 const ok=u.ativo&&await bcrypt.compare(senha,u.senha_hash);
 if(!ok){ const falhas=(rate.rows[0]?.falhas||0)+1, bloqueia=falhas>=5, ate=bloqueia?new Date(Date.now()+5*60000):null;
   await db.query('INSERT INTO tentativas_login(email,falhas,bloqueado_ate,atualizado_em) VALUES($1,$2,$3,now()) ON CONFLICT(email) DO UPDATE SET falhas=$2,bloqueado_ate=$3,atualizado_em=now()',[email,bloqueia?0:falhas,ate]);
   if(u) await db.query('UPDATE usuario SET tentativas_falhas=$1,bloqueado_ate=$2 WHERE id_usuario=$3',[bloqueia?0:falhas,ate,u.id_usuario]);
   await log(email,bloqueia?'BLOQUEIO':'LOGIN_FALHA',u?.id_usuario||null,req.ip); return res.status(401).json({erro:'E-mail ou senha inválidos.'}); }
 await db.query('DELETE FROM tentativas_login WHERE email=$1',[email]); await db.query('UPDATE usuario SET tentativas_falhas=0,bloqueado_ate=NULL,ultimo_acesso=now() WHERE id_usuario=$1',[u.id_usuario]); await log(email,'LOGIN_SUCESSO',u.id_usuario,req.ip); const usuario={id:u.id_usuario,nome:u.nome,email:u.email,cargo:u.cargo,trocarSenha:u.trocar_senha}; const token=await iniciarSessao(usuario); res.json({...usuario,token});
 }catch(e){next(e)}});
router.post('/logout',permitir(),async(req,res,next)=>{try{const u=req.session.usuario;await log(u.email,'LOGOUT',u.id,req.ip);await encerrarSessao(req);res.clearCookie('ger.sid').json({ok:true});}catch(e){next(e)}});
router.get('/me',permitir(),(req,res)=>res.json(req.session.usuario));
router.post('/senha',permitir(),async(req,res,next)=>{try{
 const {atual,nova}=req.body||{};
 if(!nova||nova.length<8||!/[A-Za-zÀ-ÿ]/.test(nova)||!/[0-9]/.test(nova))return res.status(400).json({erro:'A nova senha deve ter ao menos 8 caracteres, incluindo letras e números.'});
 const q=await db.query('SELECT senha_hash FROM usuario WHERE id_usuario=$1',[req.session.usuario.id]);
 if(!q.rowCount)return res.status(401).json({erro:'Usuário não encontrado.'});
 if(!req.session.usuario.trocarSenha&&(!atual||!(await bcrypt.compare(atual,q.rows[0].senha_hash))))return res.status(400).json({erro:'Informe a senha atual correta.'});if(req.session.usuario.trocarSenha&&atual&&!(await bcrypt.compare(atual,q.rows[0].senha_hash)))return res.status(400).json({erro:'Senha provisória incorreta.'});
 const h=await bcrypt.hash(nova,12);
 await db.query('UPDATE usuario SET senha_hash=$1,trocar_senha=false WHERE id_usuario=$2',[h,req.session.usuario.id]);
 await log(req.session.usuario.email,'TROCA_SENHA',req.session.usuario.id,req.ip);
 await revogarSessoesUsuario(req.session.usuario.id);
 const token=await iniciarSessao(req.session.usuario);
 res.json({ok:true,token});
 }catch(e){next(e)}});
router.get('/usuarios',permitir('Dono'),async(req,res,next)=>{try{const r=await db.query('SELECT u.id_usuario,u.nome,u.email,u.ativo,u.trocar_senha,c.nome AS cargo FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo ORDER BY u.nome');res.json(r.rows)}catch(e){next(e)}});
router.post('/usuarios',permitir('Dono'),async(req,res,next)=>{try{const {nome,email,cargo}=req.body||{};if(!nome||!email||!['Gerente','Estoquista','Cozinheiro(a)','Garçom/Caixa'].includes(cargo))return res.status(400).json({erro:'Informe nome, e-mail e um perfil válido.'});const senha_provisoria=require('crypto').randomBytes(7).toString('hex')+'A8';const h=await bcrypt.hash(senha_provisoria,12);const r=await db.query('INSERT INTO usuario(nome,email,senha_hash,trocar_senha,fk_cargo_id_cargo) VALUES($1,lower($2),$3,true,(SELECT id_cargo FROM cargo WHERE nome=$4)) RETURNING id_usuario,nome,email,ativo,trocar_senha',( [nome,email,h,cargo]));await log(email,'USUARIO_CRIADO',r.rows[0].id_usuario,req.ip,'Conta criada pelo Dono.');res.status(201).json({...r.rows[0],cargo,senha_provisoria});}catch(e){next(e)}});

router.put('/usuarios/:id/status',permitir('Dono'),async(req,res,next)=>{try{const ativo=!!req.body?.ativo;if(Number(req.params.id)===req.session.usuario.id&&!ativo)return res.status(400).json({erro:'O Dono não pode desativar a própria conta.'});if(!ativo){const last=await db.query("SELECT count(*)::int AS n FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo WHERE c.nome='Dono' AND u.ativo AND u.id_usuario<>$1",[req.params.id]);const target=await db.query('SELECT c.nome FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo WHERE u.id_usuario=$1',[req.params.id]);if(target.rows[0]?.nome==='Dono'&&last.rows[0].n===0)return res.status(400).json({erro:'É necessário manter pelo menos um Dono ativo.'});}const r=await db.query('UPDATE usuario SET ativo=$1 WHERE id_usuario=$2 RETURNING id_usuario,nome,email,ativo',[ativo,req.params.id]);if(!r.rowCount)return res.status(404).json({erro:'Usuário não encontrado.'});if(!ativo)await revogarSessoesUsuario(r.rows[0].id_usuario);await log(r.rows[0].email,ativo?'USUARIO_CRIADO':'USUARIO_DESATIVADO',r.rows[0].id_usuario,req.ip);res.json(r.rows[0]);}catch(e){next(e)}});
router.post('/usuarios/:id/redefinir-senha',permitir('Dono'),async(req,res,next)=>{try{const temporaria=require('crypto').randomBytes(9).toString('base64url')+'A7';const hash=await bcrypt.hash(temporaria,12);const r=await db.query('UPDATE usuario SET senha_hash=$1,trocar_senha=true,tentativas_falhas=0,bloqueado_ate=NULL WHERE id_usuario=$2 RETURNING id_usuario,email',[hash,req.params.id]);if(!r.rowCount)return res.status(404).json({erro:'Usuário não encontrado.'});await revogarSessoesUsuario(r.rows[0].id_usuario);await log(r.rows[0].email,'TROCA_SENHA',r.rows[0].id_usuario,req.ip,'Senha provisória redefinida pelo Dono.');res.json({ok:true,senha_provisoria:temporaria,mensagem:'Entregue a senha provisória ao usuário por canal seguro.'});}catch(e){next(e)}});
router.delete('/usuarios/:id',permitir('Dono'),async(req,res,next)=>{try{const id=Number(req.params.id);if(id===req.session.usuario.id)return res.status(400).json({erro:'Você não pode excluir sua própria conta enquanto estiver conectado.'});const target=await db.query('SELECT u.email,c.nome AS cargo FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo WHERE u.id_usuario=$1',[id]);if(!target.rowCount)return res.status(404).json({erro:'Usuário não encontrado.'});if(target.rows[0].cargo==='Dono'){const active=await db.query("SELECT count(*)::int AS n FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo WHERE c.nome='Dono' AND u.ativo AND u.id_usuario<>$1",[id]);if(active.rows[0].n===0)return res.status(400).json({erro:'É necessário manter pelo menos um Dono ativo.'});}await db.query('DELETE FROM usuario WHERE id_usuario=$1',[id]);res.json({ok:true});}catch(e){if(e.code==='23503')return res.status(409).json({erro:'Este usuário possui histórico de operações. Desative a conta para preservar a auditoria.'});next(e)}});
module.exports=router;
