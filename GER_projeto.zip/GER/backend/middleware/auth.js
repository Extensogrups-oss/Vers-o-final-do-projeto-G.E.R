const permitir = (...perfis) => (req, res, next) => {
  if (!req.session?.usuario) return res.status(401).json({ erro: 'Faça login para continuar.' });
  if (perfis.length && !perfis.includes(req.session.usuario.cargo)) return res.status(403).json({ erro: 'Seu perfil não tem permissão para esta operação.' });
  next();
};
module.exports = { permitir };
