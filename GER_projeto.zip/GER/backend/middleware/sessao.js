// Sessão POR ABA: em vez de cookie (compartilhado por todas as abas do navegador),
// cada login gera um token aleatório que o navegador guarda no sessionStorage da aba
// e envia no cabeçalho "Authorization: Bearer <token>". O servidor guarda apenas o
// HASH do token na tabela "session" do PostgreSQL.
const crypto = require('crypto');
const expressSession = require('express-session');           // usado só como base da classe Store
const PgSession = require('connect-pg-simple')(expressSession);
const db = require('../db');

const OCIOSIDADE_MS = 15 * 60 * 1000;                         // 15 min sem uso encerra a sessão
const store = new PgSession({ pool: db, tableName: 'session', createTableIfMissing: true });
const esperar = fn => new Promise((ok, falha) => fn((e, r) => (e ? falha(e) : ok(r))));
const chave = token => crypto.createHash('sha256').update(token).digest('hex');
const expira = () => ({ expires: new Date(Date.now() + OCIOSIDADE_MS) });

// Executa em toda requisição /api: se houver token válido, preenche req.session.usuario.
async function carregarSessao(req, res, next) {
  req.session = null; req.sessionToken = null;
  const m = /^Bearer ([A-Za-z0-9_-]{43})$/.exec(req.get('authorization') || '');
  if (!m) return next();
  try {
    const sid = chave(m[1]);
    const sess = await esperar(f => store.get(sid, f));
    if (!sess?.usuario?.id) return next();
    // Dados sempre atuais do banco: conta desativada/excluída perde o acesso na hora.
    const q = await db.query('SELECT u.id_usuario,u.nome,u.email,u.ativo,u.trocar_senha,c.nome AS cargo FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo WHERE u.id_usuario=$1', [sess.usuario.id]);
    const u = q.rows[0];
    if (!u || !u.ativo) { await esperar(f => store.destroy(sid, f)); return next(); }
    sess.cookie = expira();
    await esperar(f => store.touch(sid, sess, f));            // renova os 15 min de ociosidade
    req.session = { usuario: { id: u.id_usuario, nome: u.nome, email: u.email, cargo: u.cargo, trocarSenha: u.trocar_senha } };
    req.sessionToken = m[1];
    next();
  } catch (e) { next(e); }
}

// Cria uma sessão nova (sempre token novo) e devolve o token para o navegador.
async function iniciarSessao(usuario) {
  // Sessão única por usuário: um novo login substitui a sessão anterior,
  // inclusive quando ela está aberta em outra aba ou janela.
  await revogarSessoesUsuario(usuario.id);
  const token = crypto.randomBytes(32).toString('base64url');   // 43 caracteres
  await esperar(f => store.set(chave(token), { usuario: { id: usuario.id }, cookie: expira() }, f));
  return token;
}

async function encerrarSessao(req) {
  if (req.sessionToken) await esperar(f => store.destroy(chave(req.sessionToken), f));
  req.session = null;
}

// Revoga todas as abas/dispositivos do usuário após alteração ou redefinição de senha.
async function revogarSessoesUsuario(usuarioId) {
  await db.query('DELETE FROM "session" WHERE sess->\'usuario\'->>\'id\' = $1', [String(usuarioId)]);
}

module.exports = { carregarSessao, iniciarSessao, encerrarSessao, revogarSessoesUsuario };
