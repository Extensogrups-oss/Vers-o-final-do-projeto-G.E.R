require('dotenv').config();
const express=require('express'); const { carregarSessao }=require('./middleware/sessao'); const helmet=require('helmet'); const path=require('path'); const db=require('./db');
const app=express(); if(process.env.NODE_ENV==='production') app.set('trust proxy',1); app.disable('x-powered-by'); app.use(helmet({contentSecurityPolicy:false})); app.use(express.json({limit:'2mb'}));
app.use('/api',(req,res,next)=>{res.set('Cache-Control','no-store');if(/ger\.sid=/.test(req.headers.cookie||''))res.clearCookie('ger.sid');next()});
app.use('/api',carregarSessao);
// Uma senha provisória só permite consultar a sessão e definir a senha definitiva.
app.use('/api',(req,res,next)=>{
  if(!req.session?.usuario?.trocarSenha)return next();
  // Status e login continuam acessíveis para que a tela seja reconstruída após F5.
  // Isso permite retomar a etapa de senha provisória sem precisar gerar outro código.
  const permitido=(req.method==='GET'&&(req.path==='/me'||req.path==='/status'))||
    (req.method==='POST'&&(req.path==='/senha'||req.path==='/logout'||req.path==='/login'));
  if(permitido)return next();
  return res.status(403).json({erro:'Defina sua nova senha para continuar.',codigo:'SENHA_PENDENTE'});
});
app.use('/api',require('./routes/auth')); app.use('/api',require('./routes/operacoes'));
app.use(express.static(path.join(__dirname,'../frontend'),{etag:true,setHeaders:res=>res.setHeader('Cache-Control','no-cache')}));
app.get('/api/health',async(req,res)=>{try{await db.query('SELECT 1');res.json({ok:true,banco:'conectado'});}catch{res.status(503).json({ok:false,banco:'indisponível'});}});
app.use((err,req,res,next)=>{console.error(err);if(res.headersSent)return next(err);if(err.code==='23505')return res.status(409).json({erro:'Já existe um registro com esses dados.'});if(err.code==='23503')return res.status(400).json({erro:'Operação não permitida: existem registros relacionados.'});if(err.code==='23514'||err.code==='22P02'||err.code==='22003')return res.status(400).json({erro:'Dados inválidos. Confira os valores informados.'});res.status(500).json({erro:'Erro interno ao processar a solicitação.'});});
const port=Number(process.env.PORT||3000); app.listen(port,async()=>{console.log(`G.E.R. disponível em http://localhost:${port}`);
  try{const r=await db.query("SELECT count(*)::int AS n FROM usuario u JOIN cargo c ON c.id_cargo=u.fk_cargo_id_cargo WHERE c.nome='Dono' AND u.ativo");
    console.log(r.rows[0].n?`Dono já cadastrado (${r.rows[0].n}). Tela de login ativa. Esqueceu o acesso? Rode: npm run dono`:'Nenhum Dono cadastrado: o primeiro acesso pela tela inicial criará o Dono.');
  }catch(e){console.error('Não foi possível consultar o banco na inicialização:',e.message,'\nRode: npm run diagnostico')}});
