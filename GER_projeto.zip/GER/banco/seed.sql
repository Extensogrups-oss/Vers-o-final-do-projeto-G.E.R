-- Dados demonstrativos inspirados no protótipo acadêmico. Não são dados de produção.
BEGIN;
INSERT INTO cargo(nome) VALUES ('Dono'),('Gerente'),('Estoquista'),('Cozinheiro(a)'),('Garçom/Caixa') ON CONFLICT DO NOTHING;
INSERT INTO insumo(nome,unidade_medida,custo_unitario,quantidade_estoque,estoque_minimo) VALUES
('Carne suína','kg',22,28,20),('Costela suína','kg',34,12.5,20),('Feijão vermelho','kg',9,40,15),('Arroz','kg',5,60,25),('Farinha de mandioca','kg',7,12,5),('Couve','kg',8,6,3),('Linguiça','kg',25,15,8),('Ovos','un',0.9,120,60),('Refrigerante lata','un',3,90,48),('Doce de leite','kg',30,5,2),('Queijo minas','kg',38,9,4),('Embalagem marmitex','un',0.8,200,100)
ON CONFLICT(nome) DO NOTHING;
INSERT INTO prato(nome,categoria,preco_venda) VALUES
('Tutu à Mineira','Prato feito',32),('Feijão Tropeiro','Prato feito',34),('Prato Feito Suíno','Prato feito',28),('Marmitex Costela','Marmitex',38),('Marmitex Suíno','Marmitex',30),('Refrigerante lata','Bebidas',6),('Doce de leite c/ queijo','Sobremesas',14)
ON CONFLICT(nome) DO NOTHING;
INSERT INTO ficha_tecnica_compoe(fk_insumo_id_insumo,fk_prato_id_prato,quantidade_usada)
SELECT i.id_insumo,p.id_prato,x.qtd FROM (VALUES
('Feijão vermelho','Tutu à Mineira',.25),('Couve','Tutu à Mineira',.10),('Farinha de mandioca','Tutu à Mineira',.05),('Linguiça','Tutu à Mineira',.10),
('Feijão vermelho','Feijão Tropeiro',.20),('Farinha de mandioca','Feijão Tropeiro',.08),('Linguiça','Feijão Tropeiro',.10),('Ovos','Feijão Tropeiro',1),('Couve','Feijão Tropeiro',.05),('Arroz','Feijão Tropeiro',.15),
('Carne suína','Prato Feito Suíno',.20),('Arroz','Prato Feito Suíno',.15),('Feijão vermelho','Prato Feito Suíno',.15),('Couve','Prato Feito Suíno',.05),
('Costela suína','Marmitex Costela',.30),('Arroz','Marmitex Costela',.20),('Feijão vermelho','Marmitex Costela',.25),('Embalagem marmitex','Marmitex Costela',1),
('Carne suína','Marmitex Suíno',.25),('Arroz','Marmitex Suíno',.20),('Feijão vermelho','Marmitex Suíno',.25),('Embalagem marmitex','Marmitex Suíno',1),
('Refrigerante lata','Refrigerante lata',1),('Doce de leite','Doce de leite c/ queijo',.10),('Queijo minas','Doce de leite c/ queijo',.08)
) AS x(insumo,prato,qtd) JOIN insumo i ON i.nome=x.insumo JOIN prato p ON p.nome=x.prato
ON CONFLICT(fk_insumo_id_insumo,fk_prato_id_prato) DO NOTHING;
INSERT INTO calendario_demanda(data_demanda,descricao_evento,fator_demanda) VALUES
('2026-11-02','Finados',2.5),('2026-11-15','Proclamação da República',2.2),('2026-11-20','Dia da Consciência Negra',2.2),('2026-12-25','Natal',2.2),('2027-01-01','Confraternização Universal',2.2)
ON CONFLICT(data_demanda) DO NOTHING;
COMMIT;
