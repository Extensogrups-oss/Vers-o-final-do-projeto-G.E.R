-- Consultas de conferência após schema.sql e seed.sql
SELECT * FROM cargo ORDER BY id_cargo;
SELECT nome, unidade_medida, quantidade_estoque, estoque_minimo, custo_unitario FROM insumo ORDER BY nome;
SELECT * FROM vw_saldo_critico ORDER BY status, nome;
SELECT * FROM vw_cmv_prato ORDER BY nome;
SELECT * FROM calendario_demanda ORDER BY data_demanda;
SELECT * FROM movimentacao_estoque ORDER BY data_hora DESC LIMIT 30;
SELECT * FROM divergencia_estoque ORDER BY registrada_em DESC;
SELECT * FROM log_acesso ORDER BY data_hora DESC LIMIT 30;

-- Teste de restrição: deve falhar por CHECK (quantidade_estoque >= 0).
-- Execute isoladamente para observar o erro; não é necessário para o uso normal.
-- UPDATE insumo SET quantidade_estoque = -1 WHERE id_insumo = 1;

-- Teste de proteção referencial: deve falhar se o insumo tiver ficha técnica/movimentação/auditoria.
-- DELETE FROM insumo WHERE id_insumo = 1;
