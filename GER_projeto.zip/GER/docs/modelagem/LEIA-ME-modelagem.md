# Modelos conceitual e lógico para complementar no BrModelo

Os arquivos `.mmd` são diagramas Mermaid de referência e a tabela abaixo lista as entidades e os relacionamentos para redesenhar/atualizar no BrModelo. Os arquivos `.brM3` originais foram preservados em `docs/originais/`.

## Como representar no modelo conceitual (MER)

Entidades: Cargo, Usuario, Insumo, Prato, CalendarioDemanda, Venda, ItemVenda, MovimentacaoEstoque, Auditoria, LogAcesso, ImportacaoPDV, DivergenciaEstoque e RelatoAuditoria. A entidade associativa `FichaTecnicaCompoe` resolve a relação N:N entre Insumo e Prato e possui o atributo `quantidade_usada`.

Relacionamentos principais:
- Cargo 1:N Usuario.
- Usuario 1:N Venda; Usuario 1:N MovimentacaoEstoque; Usuario 1:N LogAcesso.
- Prato 1:N ItemVenda e Venda 1:N ItemVenda.
- Insumo N:N Prato, resolvido por FichaTecnicaCompoe.
- Insumo 1:N MovimentacaoEstoque e Insumo 1:N Auditoria.
- Venda 1:0..1 ImportacaoPDV (apenas venda importada) e Venda 1:N DivergenciaEstoque.
- Insumo 1:N DivergenciaEstoque.
- CalendarioDemanda influencia o planejamento e o estoque mínimo dinâmico; não participa da baixa física real.

## Modelo lógico (MLD)

Use os atributos e chaves do `modelo_logico.mmd`. Todas as FKs seguem o script `banco/schema.sql`. A chave da ficha técnica é composta por `(fk_insumo_id_insumo, fk_prato_id_prato)`. `item_venda` tem PK própria `id_item_venda` e uma restrição UNIQUE para `(fk_venda_id_venda, fk_prato_id_prato)`.

## Observação sobre o formato BrModelo

`.brM3` é um formato binário serializado próprio do BrModelo. Não é seguro editar esses arquivos como texto nem gerar um `.brM3` por conversão improvisada. Por isso, os modelos de referência foram entregues em Mermaid e em especificação textual para você reproduzir no BrModelo e salvar no formato nativo. Os originais estão preservados sem alteração.
