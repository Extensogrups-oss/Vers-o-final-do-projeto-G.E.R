# Regras da análise original × onde vivem na estrutura atual (API + PostgreSQL)

Use esta tabela antes de mexer em layout: a regra de negócio **não** está mais no navegador, está no banco/API.
Mudar o visual (CSS/HTML) não altera nenhuma regra desta lista, desde que os pontos abaixo sejam preservados.

## 1. Perfis (RBAC)
| Perfil | Menu (frontend `acessoModulos` em app.js) | Escrita permitida (backend `permitir(...)`) |
|---|---|---|
| Dono | todos + gestão de usuários | tudo |
| Gerente | todos (sem gestão de usuários) | tudo, exceto `/usuarios` |
| Estoquista | dashboard, insumos, auditoria | entrada e perda de insumos, relatos |
| Cozinheiro(a) | dashboard, insumos, cardápio, auditoria | perda de insumos, relatos, ver ficha técnica |
| Garçom/Caixa | dashboard, cardápio, vendas, auditoria | vender, importar vendas, relatos |

- O menu esconde módulos, mas **quem garante a regra é a API** (`backend/routes/operacoes.js`, `auth.js`). Se criar um módulo novo, proteja a rota com `permitir(...)` e inclua o módulo em `acessoModulos`.
- "Usuário" no menu é a página da própria conta (trocar senha), disponível a todos.
- Dados financeiros: `GET /api/resultado-dia` (Dono/Gerente) e `GET /api/vendas` (Dono/Gerente/Garçom).

## 2. Cálculos
| Regra | Onde está | Fórmula |
|---|---|---|
| Fator do dia | `fn_fator_demanda` (schema.sql) | evento do calendário → senão sáb/dom 1,8 → senão 1,0 |
| Mínimo dinâmico e status | view `vw_saldo_critico` | mínimo base × fator; CRITICO < mínimo; ATENCAO ≤ mínimo × 1,3 |
| Custo e margem do prato | view `vw_cmv_prato` | Σ(qtd da ficha × custo do insumo); margem = preço − custo |
| Faturamento, CMV, lucro, margem do dia | `GET /api/resultado-dia` | Σ(preço × qtd); Σ(custo do prato × qtd); lucro = fat − CMV; margem = lucro ÷ fat × 100 |
| Custo médio na entrada | `fn_registrar_entrada` | média ponderada pelo saldo |

## 3. Ciclo da venda (PDV)
1. Comanda montada no navegador (`cart`), enviada em `POST /api/vendas`.
2. A API grava venda + itens numa **transação**.
3. O gatilho `trg_baixa_estoque_venda` soma o consumo de todos os pratos pela ficha técnica, confere o saldo (venda do GER sem saldo → erro "Estoque insuficiente" e **nada** é gravado) e baixa o estoque com 3 casas decimais.
4. Cada baixa gera registro em `movimentacao_estoque` (auditoria: quem, quando, saldo antes/depois).
5. Vendas importadas do PDV externo não são recusadas: o que faltar vira `divergencia_estoque`.

## 4. Importação
`parseXml` (NFC-e: `dhEmi`, `nNF`, `det`, `cProd`, `xProd`, `qCom`, `vUnCom`) e `parseDelimited` (CSV com `,` ou `;`, colunas reconhecidas por expressão regular) em `frontend/js/app.js`, enviando para `POST /api/vendas/importar`.

## 5. Interface (v4)
- Balões: o X (`#modalClose`) fecha; Enter aciona Salvar; Salvar é travado durante o envio (sem duplicar registros); `Esc` também fecha.
- Tipografia em `rem` (base 16px, 17px ≥1500px, 19px ≥2000px); alvos de toque ≥ 44px; tabelas viram cartões em telas ≤ 640px (rótulos automáticos via `data-label`).

## 6. Sessão por aba (v5)
- `backend/middleware/sessao.js`: cada login cria um token novo (32 bytes aleatórios). O banco guarda só o SHA-256 do token (`session.sid`). Expira após 15 min sem uso (renovado a cada requisição).
- A cada requisição o servidor relê o usuário no banco: conta desativada/excluída perde o acesso na hora e o cargo/`trocarSenha` nunca ficam desatualizados.
- Frontend: `getToken/setToken/authHeader` em `app.js` (sessionStorage = próprio de cada aba, sobrevive ao F5, some ao fechar a aba). Qualquer `fetch` novo para `/api` deve incluir `...authHeader()` nos headers (a função `api()` já faz isso).
