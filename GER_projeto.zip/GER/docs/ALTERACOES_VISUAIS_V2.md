# Atualização visual do G.E.R. — versão de trabalho

Esta atualização reorganiza a interface do G.E.R. usando o protótipo original como referência visual e preserva a arquitetura HTML/CSS/JavaScript + API Node.js + PostgreSQL.

## Arquivos atualizados
- `frontend/index.html`: login, navegação lateral, cabeçalho, menu do usuário e estrutura de modal.
- `frontend/css/style.css`: tema escuro marrom-carvão, azul-marinho e laranja, responsividade, tabelas, cartões, calendário e modais.
- `frontend/js/app.js`: Dashboard, Insumos, Cardápio, Demanda, PDV/Vendas, Auditoria e Usuário(s), formulários modais e tratamento de sessão.
- `backend/routes/auth.js`: regra de senha com letras e números e geração automática de senha provisória para funcionários.
- `backend/routes/operacoes.js`: edição/desativação de insumos e pratos, exclusão de eventos, relatos de auditoria e consulta de vendas para usuários autenticados.
- `package.json`: `npm run check` também verifica o JavaScript do frontend.

## Importante
1. O arquivo `.env` não faz parte do ZIP. Preserve o `.env` que já existe na pasta de trabalho.
2. O banco PostgreSQL não é recriado nem apagado por esta atualização.
3. Não execute novamente `schema.sql` ou `seed.sql` por causa desta atualização.
4. A importação está preparada para XML de NFC-e e CSV/TXT estruturados. A extensão `.MSL` foi incluída no seletor, mas o formato específico do Mestre Sistemas precisa ser validado com um arquivo de exemplo real antes de afirmar compatibilidade.
5. O pedido de compra, nesta etapa, é uma sugestão calculada na tela; ainda não é uma ordem enviada a fornecedor.
6. A exclusão de insumos vinculados a fichas técnicas é bloqueada para preservar a integridade. Usuários com histórico também podem não poder ser excluídos; nesses casos, desative a conta.

## Aplicação no computador
- Pare o servidor com `Ctrl + C`.
- Faça uma cópia de segurança da pasta `GER`.
- Extraia os arquivos deste ZIP sobre a pasta `GER` existente, permitindo substituir os arquivos correspondentes.
- Não apague o arquivo `.env` nem a pasta `node_modules`.
- No terminal, execute `npm.cmd run check`.
- Depois execute `npm.cmd start` e teste as telas e operações.
