# Adendo técnico — decisões e regras consolidadas do G.E.R.

## 1. Banco de dados

O arquivo definitivo de entrada é `banco/schema.sql`, derivado de `físico_ext.sql` e complementado com tabelas de vendas, itens de venda, movimentações, logs de acesso, importações do PDV, divergências e relatos. `banco/seed.sql` contém apenas dados demonstrativos. A conta Dono é criada pela API no primeiro acesso; não há senha padrão no seed.

## 2. Fator de demanda e consumo real

O fator de demanda é aplicado ao planejamento: previsão de consumo, estoque mínimo dinâmico e preparação de compras. Quando uma venda efetivamente ocorre, o consumo físico é calculado exclusivamente pela ficha técnica multiplicada pela quantidade vendida. Não se multiplica novamente a baixa pelo fator do calendário, pois isso registraria consumo que não ocorreu.

O fator de um dia de maior movimento serve para orientar o preparo e o abastecimento dos próximos dias/pratos planejados, não para reescrever vendas passadas.

## 3. RN02 e RNF02 — comportamento diante de estoque insuficiente

**RN02 — Integridade do estoque:** o saldo físico de um insumo nunca pode ficar negativo. Toda movimentação deve ser rastreável.

**RNF02 — Atomicidade da venda direta:** ao lançar uma venda diretamente no G.E.R., a baixa dos ingredientes é uma única transação. Se faltar qualquer ingrediente, a venda inteira é revertida (rollback): nenhum item da venda nem baixa parcial permanece gravado. A API informa o motivo do cancelamento, incluindo o insumo, saldo disponível, quantidade necessária e quantidade faltante.

**Regra específica para importação do PDV:** uma venda já concluída no Mestre Sistemas não deve ser descartada por divergência de estoque na retaguarda. Ela é importada uma única vez, os saldos disponíveis são baixados até zero e a quantidade faltante é registrada em `divergencia_estoque`. A venda, a importação, as movimentações e as divergências são confirmadas na mesma transação. A chave externa única evita duplicidade.

## 4. Baixa automática única

A baixa é concentrada na função/trigger do PostgreSQL. O backend apenas inicia a transação e grava cabeçalho e itens; não subtrai os ingredientes por fora. A constraint trigger diferida executa no commit, quando todos os itens já existem. Isso preserva atomicidade e impede baixa duplicada.

## 5. Entradas e perdas

Entradas recalculam o custo médio ponderado: `(saldo anterior × custo médio anterior + quantidade recebida × custo de entrada) / saldo após entrada`. Perdas exigem justificativa e geram movimentação e auditoria na mesma transação.

## 6. Segurança

- Hash de senha com bcrypt no servidor; senha nunca é devolvida pela API.
- Sessão no servidor, persistida no PostgreSQL, com cookie `HttpOnly`, `SameSite=Lax` e `Secure` em produção HTTPS.
- Expiração por inatividade em 15 minutos.
- Autorização por perfil no middleware de cada rota protegida.
- Consultas SQL parametrizadas.
- Cinco falhas de autenticação bloqueiam temporariamente a conta por cinco minutos; falhas e acessos são registrados em `log_acesso`.
- O Express serve a interface e a API na mesma origem; o frontend chama caminhos relativos `/api/...`.

## 7. Escopo da interface

O site original era um protótipo local baseado em `localStorage` e `sessionStorage`. Nesta etapa foi criada uma interface integrada que utiliza `fetch()` e a API, mantendo o protótipo original preservado. O protótipo não deve ser apresentado como se já fosse uma aplicação multiusuário segura; a versão integrada é a que deve ser executada pelo servidor.
